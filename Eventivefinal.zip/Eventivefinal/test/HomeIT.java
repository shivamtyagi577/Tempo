/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Connection;
import java.sql.DriverManager;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author admin
 */
public class HomeIT {
    
    public HomeIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of con method, of class Home.
     */
    @Test
    public void testCon() {
        System.out.println("con");
        Home instance = new Home();
        //Connection expResult = null;
        Connection expResult = null;
//        try
//        {
//            Class.forName("com.mysql.jdbc.Driver");  
//            expResult = DriverManager.getConnection("jdbc:mysql://localhost:3307/eventivefinal","root","Abroad123#");  
//        }
//        catch(Exception e)
//        {
//            System.out.println(e.getMessage());
//        }
        Connection result = instance.con();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class Home.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Home.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setVisible method, of class Home.
     */
    @Test
    public void testSetVisible() {
        System.out.println("setVisible");
        Home instance = new Home();
        instance.setVisible();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
