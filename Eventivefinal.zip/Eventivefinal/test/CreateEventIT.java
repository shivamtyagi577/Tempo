/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Connection;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.mockito.Mock;
import org.mockito.Mockito;
import mockit.Deencapsulation;


/**
 *
 * @author admin
 */
public class CreateEventIT {
    
    @Mock
    javax.swing.JTextField CustomerName;
    @Mock
    javax.swing.JButton CreateAptBtn;
    @Mock
    javax.swing.JTextField CustAge;
    @Mock    
    javax.swing.JTextField CustIdentity;
    @Mock    
    javax.swing.JTextField CustomerEmail;
    @Mock
    java.awt.event.ActionEvent evt;
    @Mock
    javax.swing.JTextField CustomerPhone;
    @Mock
    javax.swing.JComboBox<String> EventType;
    @Mock
    javax.swing.JComboBox<String> EventCategory;
    
    
    public CreateEventIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of con method, of class CreateEvent.
     */
    @Test
    public void testCon() {
        System.out.println("con");
        CreateEvent instance = new CreateEvent();
        Connection expResult = null;
        Connection result = instance.con();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class CreateEvent.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        CreateEvent.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
    @Test
    void testCreateEvent(){
        CreateEvent ce=new CreateEvent();
        
        
        Connection c=Mockito.mock(Connection.class);
        
        
        Mockito.when(CustomerName.getText()).thenReturn("Paridhi");
        Mockito.when(CustAge.getText()).thenReturn("21");
        Mockito.when(CustIdentity.getText()).thenReturn("21");
        Mockito.when(CustomerEmail.getText()).thenReturn("paridhi@gmail.com");
        Mockito.when(CustomerPhone.getText()).thenReturn("8126519330");
        Mockito.when(EventType.getSelectedItem()).thenReturn("Wedding");
        Mockito.when(EventCategory.getSelectedItem()).thenReturn("Wedding");
//        Mockito.when(EventType.getSelectedItem()).thenReturn("Option1");
        mockit.Deencapsulation.invoke(ce,"CreateAptBtnActionPerformed",evt);
        assert true;
    }
    
}
