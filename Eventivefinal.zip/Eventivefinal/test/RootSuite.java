/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author admin
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({BillSummaryIT.class, AdminIT.class, ExDecoIT.class, WeddingIT.class, EventIT.class, Theme_LuxIT.class, ThemeDecorIT.class, HintJTextFieldIT.class, BillIT.class, ExBillIT.class, eventivefinal.EventivefinalITSuite.class, EmployeeIT.class, StayIT.class, wed_luxIT.class, Award_CeremonyIT.class, ThemepIT.class, ExTransportIT.class, TimeandTransportIT.class, AboutIT.class, AwardTransportIT.class, GalleryIT.class, BillThemeIT.class, pregress_empIT.class, progressIT.class, ExCaterIT.class, CreateEventIT.class, ProfileIT.class, AwardBillIT.class, event_progressIT.class, ToolkitIT.class, ProgressEventIT.class, AwardDecoIT.class, ThemeCaterIT.class, Exotic_OutingsIT.class, Manage_employeeIT.class, LoginIT.class, CaterIT.class, GuideIT.class, Award_LuxIT.class, ThemeTransportIT.class, ConnectionIT.class, AppointmentIT.class, ExoticLastIT.class, AwardCaterIT.class, ExhibitionIT.class, HomeIT.class, Ex_LuxIT.class, DecorIT.class, displayIT.class, DecoIT.class, TransportIT.class})
public class RootSuite {

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }
    
}
