<?php
session_start();
include "conn.php";

//echo "a" . $_SESSION['user_mail'];

if (isset($_POST["submit"])) {
    $date = $_POST["app_date"];
    $time = $_POST["app_time"];

    if (($date == "") || ($date == 0)) {
        $msg = "Invalid date!";
        echo "<script type='text/javascript'>alert(\"$msg\");</script>";
        header("refresh:0;url=appointment.php");
        exit();
    }
    if (($time == "") || ($time == 0)) {
        $msg = "Invalid time!";
        echo "<script type='text/javascript'>alert(\"$msg\");</script>";
        header("refresh:0;url=appointment.php");
        exit();
    }

    $q1 = mysqli_query($conn, "SELECT cust_id from customer where email = '$_SESSION[user_mail]'");
    $q2 = mysqli_fetch_assoc($q1);

    $q3 = mysqli_query($conn, "INSERT INTO appointment (cust_id, app_date,app_time) VALUES ('$q2[cust_id]','$date','$time')");

    if ($q3) {
        $msg = "Appointment booked successfully! :)";
        echo "<script type='text/javascript'>alert(\"$msg\");</script>";
        header("refresh:0;url=appointment.php");
    }
}
?>

<!DOCTYPE html>
<html lang="en"><!-- Basic -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <!-- Site Metas -->
    <title>Eventive!</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/finallogo.png" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/finallogo.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Pogo Slider CSS -->
    <link rel="stylesheet" href="css/pogo-slider.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css"
          href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css">
    <style type="text/css">
        .container {
            margin-top: 40px;
        }

        .btn-primary {
            width: 100%;
        }
    </style>


    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body id="home" data-spy="scroll" data-target="#navbar-wd" data-offset="98">
<form action="appointment.php" method="post">

    <!-- LOADER -->
    <div id="preloader">
        <div class="preloader pulse">
            <h3>EVENTIVE</h3>
        </div>
    </div><!-- end loader -->
    <!-- END LOADER -->

    <!-- Start header -->
    <header class="top-header">
        <nav class="navbar header-nav navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand" href="index.html"><img src="images/finallogoeventive.png" alt="image"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-wd"
                        aria-controls="navbar-wd" aria-expanded="false" aria-label="Toggle navigation">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbar-wd">
                    <ul class="navbar-nav">
                        <li><a class="nav-link" href="index.php">Home</a></li>
                        <!--                        <li><a class="nav-link" href="#">About Us</a></li>-->
                        <!--                        <li><a class="nav-link" href="#">Story</a></li>-->
                        <!--                        <li><a class="nav-link" href="#">Family</a></li>-->
                        <!--                        <li><a class="nav-link" href="#">Gallery</a></li>-->
                        <!--                        <li><a class="nav-link" href="#">Wedding</a></li>-->
                        <!--                        <li><a class="nav-link" href="#">Events</a></li>-->
                        <li><a class="nav-link" href="appointment.php">Appointment</a></li>
<!--                        <li><a class="nav-link" href="LOG/login.html">Login</a></li>-->
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <!-- Start Contact -->
    <div id="contact" class="contact-box">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="title-box">
                        <h2>Book an appointment!</h2>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="panel panel-primary">
                    <div class="panel-heading">Enter the details!</div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label">Appointment date</label>
                                    <input type="date" class="form-control" name="app_date" id="app_date">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label" for="email">Appointment time</label>
                                    <input type="time" class="form-control" name="app_time" id="app_time">
                                </div>
                            </div>
                        </div>

                        <input type="submit" class="btn btn-primary" value="Submit" name="submit">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Contact -->
</form>
<!-- Start Footer -->
<footer class="footer-box">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <p class="footer-company-name">Copyright &copy 2020 All Rights Reserved.</p>
            </div>
        </div>
    </div>
</footer>
<!-- End Footer -->

<!-- ALL JS FILES -->
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- ALL PLUGINS -->
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/jquery.pogo-slider.min.js"></script>
<script src="js/slider-index.js"></script>
<script src="js/smoothscroll.js"></script>
<script src="js/responsiveslides.min.js"></script>
<script src="js/timeLine.min.js"></script>
<script src="js/form-validator.min.js"></script>
<script src="js/contact-form-script.js"></script>
<script src="js/custom.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/2.14.1/moment.min.js"></script>
<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

<script type='text/javascript'>
    $(document).ready(function () {
        $('#datetimepicker1').datetimepicker();
    });
</script>

</body>
</html>

<style>
    @media (min-width: 768px)
        .container-fluid>.navbar-collapse, .container-fluid>.navbar-header, .container>.navbar-collapse, .container>.navbar-header {
            margin-right: 0;
            margin-left: 220px;
        }
</style>