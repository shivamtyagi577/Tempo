<?php
//include 'conn.php';
//session_start();
//include 'boot.php';
//include 'conn.php';

$servername = "localhost";
$username = "root";
$password = "abroad123#";
$result="";

// Create connection
$conn = new mysqli($servername, $username, $password, "event");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";

if (isset($_POST['login'])) {

    $user = $_POST['username'];
    $pass = $_POST['password'];
    $pass2 = md5($pass);
    //$_SESSION['user'] = $user;
    //$_SESSION['user_id'] = $user;

    $sql1 = "SELECT * FROM login WHERE username = '" . $user . "' and password = '" . $pass . "';";
	//$sql = "select password from login where username ='" . $user ."';";
	//$result->free();
	$result = $conn->query($sql1) ;
	echo $result;
	//echo "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@";
	
	if ($result !== false && $result->num_rows > 0)
    {
		
			echo "no result";
        
		
    }
	
    else {
        
		echo "########";
		while($row = $result->fetch_assoc()){
			//echo "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@";
			
			if($row['password'] == $pass){
				//$_SESSION["USER_LOGIN_STATUS"] = 1;
				//$_SESSION["user_mail"] = $user;
				$msg = "Login Successful! :)";
				echo "<script type='text/javascript'>alert(\"$msg\");</script>";
				header("refresh:0;url=./index.php");
			}
			else{
				$msg = "Invalid credentials. Try again! :(";
				echo "<script type='text/javascript'>alert(\"$msg\");</script>";
				header("refresh:0;url=LOG/");
			}
		}
    }
	$conn->close();

    
}
