<?php
define("PROJECT_HOME","http://localhost/ATTG/LOG/");

define("PORT", "587"); // port number
define("MAIL_USERNAME", "aryasingh952533@gmail.com"); // smtp usernmae
define("MAIL_PASSWORD", "a952553@4395a"); // smtp password
define("MAIL_HOST", "smtp.gmail.com"); // smtp host
define("MAILER", "smtp");
define("SENDER_NAME", "ADMIN");
define("SERDER_EMAIL", "aryasingh952533@gmail.com");
?>