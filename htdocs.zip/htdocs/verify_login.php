<?php
session_start();
//include 'boot.php';
include 'conn.php';

if (isset($_POST['login'])) {

    $user = $_POST['username'];
    $pass = md5($_POST['password']);
    $pass2 = md5($pass);
    $_SESSION['user'] = $user;
    $_SESSION['user_id'] = $user;

    $sql1 = mysqli_query($conn, "SELECT * FROM login WHERE username = '" . $user . "' and password = '" . $pass . "'");
    if (mysqli_num_rows($sql1) == 0) {
        $msg = "Invalid credentials. Try again! :(";
        echo "<script type='text/javascript'>alert(\"$msg\");</script>";
        header("refresh:0;url=LOG/login.php");
    }

    if (mysqli_num_rows($sql1) == 1)
    {
        $_SESSION["USER_LOGIN_STATUS"] = 1;
        $_SESSION["user_mail"] = $user;
        $msg = "Login Successful! :)";
        echo "<script type='text/javascript'>alert(\"$msg\");</script>";
        header("refresh:0;url=./index.php");
    }
}
